# -*- coding: utf-8 -*-
# 来源（Source）: wzyddg/stalker_auto-trans-tool_remake
# 上游仓库: https://github.com/wzyddg/stalker_auto-trans-tool_remake (作者: wzyddg)
# 收录位置: 本仓库 assets/xray_pkg.zip; 收录/修改明细见 THIRD_PARTY_NOTICES.md 第 1 节
# 上游未声明许可证(license: null), 版权归原作者所有; 本仓库署名分发, 修改处均已注明。
"""X-Ray Engine text xml Parser by wzyddg

"""

__version__ = "1.0.0"
__author__ = "wzyddg"

from .xmlxReader import *
from .xRayTextAnalyzer import *
from .entityDefinition import *
from .xmlFileGenerator import *

__all__ = [
    "read_plain_text",
    "parse_xray_text_xml",
    "parse_xray_cfgxml_xml",
    "parse_xray_ltx_file",
    "parse_xray_script_file",
    "generateOutputXml",
    "TextEntity",
    "rusLettersString",
    "actionPattern",
    "lineBreakPattern",
    "placeholderPattern",
    "scriptPlaceHolderPattern",
    "rusLetCpl",
    "actionCpl",
    "placeholderCpl",
    "doTextLookLikeId",
    "scriptCpl",
    "allSeparateTextCpl",
    "getRecommendLangText",
    "escapeLiteralText",
    "generateOutputFileFromString",
    "replaceFromText",
    "splitTextToPiecesAtLength",
    "allSeparateTextCpl"
]
