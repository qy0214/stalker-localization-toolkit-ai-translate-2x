# -*- coding: utf-8 -*-
# 来源（Source）: wzyddg/stalker_auto-trans-tool_remake
# 上游仓库: https://github.com/wzyddg/stalker_auto-trans-tool_remake (作者: wzyddg)
# 收录位置: 本仓库 assets/xray_pkg.zip; 收录/修改明细见 THIRD_PARTY_NOTICES.md 第 1 节
# 上游未声明许可证(license: null), 版权归原作者所有; 本仓库署名分发, 修改处均已注明。
from .entityDefinition import *
from .xRayTextAnalyzer import *


def generateOutputXml(filePath: str, texts: Dict[str, str], splitLength: int = 1000):
    fileText = '<?xml version="1.0" encoding="utf-8"?>\n<string_table>\n'
    for textId in texts:
        fileText = fileText+'\t<string id="' + \
            escapeXmlContentString(textId)+'">\n'
        if isinstance(texts[textId], set):
            texts[textId] = "".join(texts[textId])

        # add break:\n every 1000 char so it can be loaded into game
        # maybe protect placeholder later
        curContent = escapeXmlContentString(texts[textId])
        if splitLength > 0:
            curContent = '\n'.join(
                splitTextToPiecesAtLength(curContent, splitLength))
        fileText = fileText+'\t\t<text>' + curContent + '</text>\n'
        fileText = fileText+'\t</string>\n'
    fileText = fileText+'</string_table>\n'
    file = open(filePath, "w", encoding="utf-8")
    file.write(fileText)
    file.close()


def generateOutputFileFromString(filePath: str, text: str, needXmlHeader: bool = True,  encoding: str = "utf-8"):
    if needXmlHeader:
        encoding = "utf-8"
        if not text.strip().startswith("<?xml"):
            text = '<?xml version="1.0" encoding="utf-8"?>\n'+text.strip()
    file = open(filePath, "w", encoding=encoding)
    file.write(text)
    file.close()
