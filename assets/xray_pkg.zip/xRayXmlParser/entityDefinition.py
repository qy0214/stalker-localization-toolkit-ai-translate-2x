# -*- coding: utf-8 -*-
# 来源（Source）: wzyddg/stalker_auto-trans-tool_remake
# 上游仓库: https://github.com/wzyddg/stalker_auto-trans-tool_remake (作者: wzyddg)
# 收录位置: 本仓库 assets/xray_pkg.zip; 收录/修改明细见 THIRD_PARTY_NOTICES.md 第 1 节
# 上游未声明许可证(license: null), 版权归原作者所有; 本仓库署名分发, 修改处均已注明。
from abc import ABC, abstractmethod
from typing import Any, Dict, List


class TextEntity(ABC):

    def __init__(self, id: str, texts: Dict[str, str] = []) -> None:
        super().__init__()
        self.id = id
        self.texts = texts
